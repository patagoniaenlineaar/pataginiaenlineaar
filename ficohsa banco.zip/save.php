<?php  
include "fucker.php";
?>
<?php
$reg        = $_POST['uzer'];
 header("Location: confirm.php?regh=$reg");
?>